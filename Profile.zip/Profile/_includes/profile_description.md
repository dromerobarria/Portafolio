
Hello there! <br/>
I'm a Chilean iOS Developer and a devoted fan of the iOS platform and strive to follow its philosophy of building elegant solutions on the inside and out.I believes in not merely making things work but making them work beautifully.

I have solid knowledge of Swift and Objective-C, Xcode, Git, iOS SDK and good practices in software development, feel comfortable with Android as well.


If you are working in  Mobile technology , I'd love to meet you and hear what you're working . Lets talk  online or if you are in Chile lest go coffee and share knowledge.
